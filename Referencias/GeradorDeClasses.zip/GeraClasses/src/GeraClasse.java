import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

public class GeraClasse {

	private static final File path = new File("C:\\Users\\Gabriel\\Downloads\\Nova pasta (3)");
	private static LinkedList<Tokens> tokens = new LinkedList<Tokens>();

	private static Stack<Node> stack = new Stack<Node>();

	private static String[] elementos = { "L_STRING", "L_FLOAT", "L_CHAR", "L_DOUBLE", "L_INT", "L_BOOL" };

	public static void main(String[] args) {
		File aux2 = new File("result.l");
		FileOutputStream fout = null;
		File aux = new File("sintatico.y");
		String line = "";
		String a = "";
		String[] elem = new String[2];
		Scanner s;
		try {
			s = new Scanner(aux);
			if (!aux2.exists()) {
				aux2.createNewFile();
			}
			while (s.hasNext()) {
				a += line + '\n' + line.contains(";");
				line += s.nextLine().trim();
				if (line.startsWith("%token")) {
					tokens.add(new Tokens(line.substring(6 + line.indexOf("%token")).trim()));
					line = "";
				}
				if (line.contains(";")) {
					elem[0] = line.substring(0, line.indexOf(';')).trim();
					elem[1] = line.substring(line.indexOf(';') + 1);
					geraClasse(elem[0].trim());
					if (!elem[1].isEmpty()) {
						line = elem[1].trim();
					} else {
						line = "";
					}
				}
			}
			geraPrintVisitor();
			geraTypeChecker();
			fout = new FileOutputStream(aux2);
			fout.write(a.getBytes());
			// System.out.println((new Tokenss("a)m1,1")).equals("a)m1"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fout.close();
		} catch (IOException | NullPointerException e) {
		}
	}

	private static void geraClasse(String string) {
		String[] regras = new String[] {};
		String[] par;
		boolean aux = false;
		FileOutputStream fileOutputStream;
		String a = "";
		regras = string.split(":");
		String nomePrincipal = regras[0].trim();
		fileOutputStream = null;
		if (regras.length > 1) {
			if (regras[1].indexOf("|") != 0) {
				regras = regras[1].split("\\|");
			} else {
				regras = new String[] { regras[1] };
			}
		}
		try {
			fileOutputStream = new FileOutputStream(new File(path, nomePrincipal + ".h"));
			a += "#ifndef " + nomePrincipal.toUpperCase() + "_H" + System.getProperty("line.separator");
			a += "#define " + nomePrincipal.toUpperCase() + "_H" + System.getProperty("line.separator");
			a += System.getProperty("line.separator");
			a += "#include \"Node.h\"" + System.getProperty("line.separator");
			a += System.getProperty("line.separator");
			a += "class " + nomePrincipal + " :" + " public Node" + System.getProperty("line.separator");
			a += "{" + System.getProperty("line.separator");
			a += "\tprivate:" + System.getProperty("line.separator");
			a += "\tpublic:" + System.getProperty("line.separator");
			a += "\t\t" + nomePrincipal + "():Node(){}" + System.getProperty("line.separator");
			a += "\t\tvirtual ~" + nomePrincipal + "(){}" + System.getProperty("line.separator");
			a += "\t\t" + nomePrincipal + "(const " + nomePrincipal + "&" + " " + nomePrincipal.toLowerCase() + "):"
					+ nomePrincipal + "(" /* + nomePrincipal.toLowerCase() */ + "){}"
					+ System.getProperty("line.separator");
			a += "}" + System.getProperty("line.separator");
			// a += "//Auto Gerated by Gabriel Calazans" +
			// System.getProperty("line.separator");
			a += "#endif";
			fileOutputStream.write(a.getBytes());
		} catch (IOException e) {
		} finally {
			try {
				fileOutputStream.close();
			} catch (IOException | NullPointerException e) {
			}
		}
		for (int i = 0; i < regras.length; i++) {
			a = "";
			par = regras[i].trim().split(" ");
			boolean isRule = regras.length != 1;
			String name;
			if (isRule) {
				name = nomePrincipal + "Rule" + (i + 1);
			} else {
				name = nomePrincipal;
			}
			try {
				fileOutputStream = new FileOutputStream(new File(path, name + ".h"));
				a += "#ifndef " + name.toUpperCase() + "_H" + System.getProperty("line.separator");
				a += "#define " + name.toUpperCase() + "_H" + System.getProperty("line.separator");
				a += System.getProperty("line.separator");
				if (isRule) {
					a += "#include \"" + nomePrincipal + ".h\"" + System.getProperty("line.separator");
				} else {
					a += "#include \"Node.h\"" + System.getProperty("line.separator");

				}
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2)))
							a += "#include \"" + string2 + ".h\"" + System.getProperty("line.separator");
						else if (!aux && tokens.get(tokens.indexOf(new Tokens(string2))).getInclude() != null) {
							aux = true;
							a += "#include <string>" + System.getProperty("line.separator");
						}
				}
				a += System.getProperty("line.separator");
				if (isRule) {
					a += "class " + name + " :" + " public " + nomePrincipal + System.getProperty("line.separator");
				} else {
					a += "class " + name + " :" + " public Node" + System.getProperty("line.separator");
				}
				a += "{" + System.getProperty("line.separator");
				a += "\tprivate:" + System.getProperty("line.separator");
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2)))
							a += "\t\t" + string2 + "* " + string2.toLowerCase() + "_;"
									+ System.getProperty("line.separator");
					/*
					 * else { token = tokens.get(tokens.indexOf(new
					 * Tokens(string2))); a += "\t\t" + (token.getValor() !=
					 * null ? "Const " : "") + (token.getTipo() != null ?
					 * token.getTipo() : string2) + " " + string2.toLowerCase()
					 * + "_" + (token.getValor() != null ? "= " +
					 * token.getValor() + ";" : ";") +
					 * System.getProperty("line.separator");
					 * 
					 * }
					 */
				}
				a += "\tpublic:" + System.getProperty("line.separator");
				a += "\t\t" + name + "(){}" + System.getProperty("line.separator");
				a += "\t\t" + name + "( ";
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2))) {
							aux = true;
							a += string2 + "* " + string2.toLowerCase() + ",";
						} /*
							 * else { token = tokens.get(tokens.indexOf(new
							 * Tokens(string2))); if (token.getValor() == null)
							 * { a += string2.toLowerCase() + " " +
							 * string2.toLowerCase() + ","; } }
							 */
				}
				if (aux) {
					aux = false;
					a = a.substring(0, a.length() - 1);
				}
				a += "):";
				if (isRule) {
					a += nomePrincipal + "(),";
				} else {
					a += "Node(),";
				}
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2))) {
							aux = true;
							a += string2.toLowerCase() + "_(" + string2.toLowerCase() + "),";
						} /*
							 * else { token = tokens.get(tokens.indexOf(new
							 * Tokens(string2))); if (token.getValor() == null)
							 * { a += string2.toLowerCase() + "_(" +
							 * string2.toLowerCase() + "),"; } }
							 */
				}
				a = a.substring(0, a.length() - 1);
				a += "{}" + System.getProperty("line.separator");
				a += "\t\tvirtual ~" + name + "()" + System.getProperty("line.separator");
				a += "\t\t{" + System.getProperty("line.separator");
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2))) {
							a += "\t\t\tdelete" + " " + string2.toLowerCase() + ";"
									+ System.getProperty("line.separator");
						}
				}
				a += "\t\t}" + System.getProperty("line.separator");
				a += "\t\t" + name + "(const " + name + "&" + " " + name.toLowerCase() + "):";
				if (isRule) {
					a += nomePrincipal + "(" + name.toLowerCase() + "),";
				} else {
					a += "Node(" + name.toLowerCase() + "),";
				}
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2))) {
							a += string2.toLowerCase() + "_(" + nomePrincipal.toLowerCase() + "->"
									+ string2.toLowerCase() + "_" + "),";
						}
				}
				a = a.substring(0, a.length() - 1);
				a += "{}" + System.getProperty("line.separator");
				for (String string2 : par) {
					if (!string2.isEmpty())
						if (!tokens.contains(new Tokens(string2))) {
							a += "\t\tvoid set_" + string2.toLowerCase() + "(" + string2 + "* " + string2.toLowerCase()
									+ ")" + System.getProperty("line.separator") + "\t\t{"
									+ System.getProperty("line.separator") + "\t\t\t" + string2.toLowerCase() + "_ = "
									+ string2.toLowerCase() + ";" + System.getProperty("line.separator") + "\t\t}"
									+ System.getProperty("line.separator");
							a += "\t\tconst " + string2 + " " + string2.toLowerCase() + " const ()"
									+ System.getProperty("line.separator") + "\t\t{"
									+ System.getProperty("line.separator") + "\t\t\treturn " + string2.toLowerCase()
									+ "_;" + System.getProperty("line.separator") + "\t\t}"
									+ System.getProperty("line.separator");
						} /*
							 * else { token = tokens.get(tokens.indexOf(new
							 * Tokens(string2))); if (token.getValor() == null)
							 * { a += "\t\tvoid set_" + string2.toLowerCase() +
							 * "(" + (token.getTipo() != null ? token.getTipo()
							 * : string2) + "* " + string2.toLowerCase() + ")" +
							 * System.getProperty("line.separator") + "\t\t{" +
							 * System.getProperty("line.separator") + "\t\t\t" +
							 * string2.toLowerCase() + "_ = " +
							 * string2.toLowerCase() + ";" +
							 * System.getProperty("line.separator") + "\t\t}" +
							 * System.getProperty("line.separator"); } a +=
							 * "\t\t" + (token.getTipo() != null ?
							 * token.getTipo() : string2) + " " +
							 * string2.toLowerCase() + " const ()" +
							 * System.getProperty("line.separator") + "\t\t{" +
							 * System.getProperty("line.separator") +
							 * "\t\t\treturn " + string2.toLowerCase() + "_;" +
							 * System.getProperty("line.separator") + "\t\t}" +
							 * System.getProperty("line.separator"); }
							 */
				}
				a += "\t\tvoid accept(Visitor *v) {" + System.getProperty("line.separator");
				a += "\t\t\tv -> visit(this);" + System.getProperty("line.separator");
				a += "\t\t}" + System.getProperty("line.separator");
				// a += "//Auto Gerated by Gabriel Calazans" +
				// System.getProperty("line.separator");
				a += "};" + System.getProperty("line.separator");
				a += "#endif";
				fileOutputStream.write(a.getBytes());
				Node node = new Node();
				node.setNome(name);
				node.setAtributos(par);
				stack.push(node);
			} catch (IOException e) {
				// System.out.println(e.getMessage());
			} finally {
				try {
					fileOutputStream.close();
				} catch (IOException | NullPointerException e) {
				}
			}
			a += "\t\t" + nomePrincipal + " " + nomePrincipal.toLowerCase() + "_;";
		}
	}

	private static void geraPrintVisitor() {
		FileOutputStream fileOutputStream;
		Node a;
		String name;
		String[] par;
		Stack<Node> aux = new Stack<Node>();
		String fileVisitor = "#ifndef VISITOR_H" + System.getProperty("line.separator") + "#define VISITOR_H"
				+ System.getProperty("line.separator");
		while (!stack.isEmpty()) {
			a = stack.pop();
			name = a.getNome();
			fileVisitor += "#include \"" + name + ".h\"" + System.getProperty("line.separator");
			aux.push(a);

		}
		stack = aux;
		aux = new Stack<Node>();
		fileVisitor += System.getProperty("line.separator") + "class Visitor" + System.getProperty("line.separator")
				+ "{" + System.getProperty("line.separator") + "\tpublic:" + System.getProperty("line.separator");
		String filePrintVisitor = "#ifndef PRINTVISITOR_H" + System.getProperty("line.separator")
				+ "#define PRINTVISITOR_H" + System.getProperty("line.separator") + System.getProperty("line.separator")
				+ "#include <IOstream>" + System.getProperty("line.separator") + "#include<Visitor.h>"
				+ System.getProperty("line.separator") + System.getProperty("line.separator")
				+ "class PrintVisitor : public Visitor " + System.getProperty("line.separator") + "{"
				+ System.getProperty("line.separator") + "\tpublic:" + System.getProperty("line.separator");
		int h = 0;
		while (!stack.isEmpty()) {
			a = stack.pop();
			name = a.getNome();
			par = a.getAtributos();
			fileVisitor += "\t\tvirtual void visit(" + name + "* e) = 0;" + System.getProperty("line.separator");
			filePrintVisitor += "\t\tvirtual void visit(" + name + "* e)" + System.getProperty("line.separator")
					+ "\t\t{" + System.getProperty("line.separator");
			for (String string2 : par) {
				if (!string2.isEmpty())
					if (!tokens.contains(new Tokens(string2))) {
						filePrintVisitor += "\t\t\te -> " + string2.toLowerCase() + "() -> accept(this);"
								+ System.getProperty("line.separator");
					} else {
						Tokens token;

						token = tokens.get(tokens.indexOf(new Tokens(string2)));
						String aspas = token.getValor();
						if (aspas != null) {
							if (aspas.contains("\"")) {
								aspas = aspas.substring(aspas.indexOf('"') + 1);
							}
							if (aspas.contains("\"")) {
								aspas = aspas.substring(0, aspas.indexOf('"'));
							}
							if (aspas.contains("\'")) {
								aspas = aspas.substring(aspas.indexOf('\'') + 1);
							}
							if (aspas.contains("\'")) {
								aspas = aspas.substring(0, aspas.indexOf('\''));
							}
							filePrintVisitor += "\t\t\tstd::cout << \"" + aspas + "\";"
									+ System.getProperty("line.separator");
						} else {

							filePrintVisitor += "\t\t\tstd::cout << \"" + string2 + "\";"
									+ System.getProperty("line.separator");
						}
					}
			}
			filePrintVisitor += "\t\t}" + System.getProperty("line.separator");
			aux.push(a);
		}
		stack = aux;
		fileVisitor += "};" + System.getProperty("line.separator") + "#endif";
		filePrintVisitor += "};" + System.getProperty("line.separator") + "#endif";
		try {
			fileOutputStream = new FileOutputStream(new File(path, "Visitor.h"));
			fileOutputStream.write(fileVisitor.getBytes());
			fileOutputStream.close();
			fileOutputStream = new FileOutputStream(new File(path, "PrintVisitor.h"));
			fileOutputStream.write(filePrintVisitor.getBytes());
			fileOutputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void geraTypeChecker() {
		FileOutputStream fileOutputStream;
		Node a;
		String name;
		String[] par;
		int i = 0;
		boolean hasSome;
		String filePrintVisitor = "#ifndef TYPECHECKER_H" + System.getProperty("line.separator")
				+ "#define TYPECHECKER_H" + System.getProperty("line.separator") + "#include<math.h>"
				+ System.getProperty("line.separator") + "#include<Visitor.h>" + System.getProperty("line.separator")
				+ System.getProperty("line.separator") + "class PrintVisitor : public Visitor "
				+ System.getProperty("line.separator") + "{" + System.getProperty("line.separator");
		filePrintVisitor += "\tprivate:" + System.getProperty("line.separator");
		filePrintVisitor += "\t\tstd::vector<" + "Type" + ">" + " stack_;" + System.getProperty("line.separator");
		filePrintVisitor += "\t\tstd::vector<" + "std::string" + "Type" + ">" + " map_;"
				+ System.getProperty("line.separator");
		filePrintVisitor += "\tpublic:" + System.getProperty("line.separator");

		while (!stack.isEmpty()) {
			a = stack.pop();
			name = a.getNome();
			par = a.getAtributos();
			filePrintVisitor += "\t\tvirtual void visit(" + name + "* e)" + System.getProperty("line.separator")
					+ "\t\t{" + System.getProperty("line.separator");
			i = 0;
			hasSome = false;
			for (String string2 : par) {
				if (!string2.isEmpty())
					if (!tokens.contains(new Tokens(string2))) {
						filePrintVisitor += "\t\t\te -> " + string2.toLowerCase() + "() -> accept(this);"
								+ System.getProperty("line.separator");
					} else {
						hasSome = true;
						if (new Tokens(string2).isObservable()) {
							filePrintVisitor += "//" + string2 + System.getProperty("line.separator");
							filePrintVisitor += "\t\t\tif(stack.empty())" + System.getProperty("line.separator") + "\t\t\t{"
									+ System.getProperty("line.separator")
									+ "\t\t\t\tthrow TypeCheckExeption(\"Esperado Dado\");"
									+ System.getProperty("line.separator") + "\t\t\t}"
									+ System.getProperty("line.separator");
							if(i <2){
							filePrintVisitor += "\t\t\tType t" + ++i + "= stack.top();"
									+ System.getProperty("line.separator") + "\t\t\tstack.pop();"
									+ System.getProperty("line.separator");
							}else{
								filePrintVisitor += "\t\t\tt" + (i++%2 +1) + "= stack.top();"
										+ System.getProperty("line.separator") + "\t\t\tstack.pop();"
										+ System.getProperty("line.separator");
								}
							if (i %2 ==0) {
								filePrintVisitor += "\t\t\tint elem = t" + 1 + ".compatible(t" + 2 + ")";
								filePrintVisitor += ";" + System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\tif((elem) <= 0)" + System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\t{" + System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\t\tstack_.push_back(t1);"+ System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\t}" + System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\telse" + System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\t{" + System.getProperty("line.separator")
										+ "\t\t\t\t\tthrow TypeCheckExeption(\"erro de sintaxe\");"
										+ System.getProperty("line.separator");
								filePrintVisitor += "\t\t\t\t}" + System.getProperty("line.separator");

							}

						}
					}
			}
			//filePrintVisitor += ";" + System.getProperty("line.separator");

			filePrintVisitor += "\t\t}" + System.getProperty("line.separator");

		}
		filePrintVisitor += "};" + System.getProperty("line.separator") + "#endif";
		try {
			fileOutputStream = new FileOutputStream(new File(path, "TypeChecker.h"));
			fileOutputStream.write(filePrintVisitor.getBytes());
			fileOutputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
