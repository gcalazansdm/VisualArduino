import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

public class GeraClasse {

	private static final File path = new File("C:\\Users\\Gabriel\\Downloads\\Nova pasta (3)");

	public static void main(String[] args) {
		File aux = new File("sintatico.y");
		String line = "";
		String[] elem;
		Scanner s;
		System.out.println(aux.getAbsolutePath());
		try {
			s = new Scanner(aux);
			while (s.hasNext()) {
				line += s.nextLine().trim();
				if (line.contains(";")) {
					elem = line.split(";");
					geraClasse(elem[0]);
					if(elem.length > 2)
						System.out.println(2);
					if (elem.length == 2) {
						line = elem[1].trim();
					} else {
						line = "";
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void geraClasse(String string) {
		String[] regras;
		String[] par;
		FileOutputStream fileOutputStream;
		String a = "";
		regras = string.split(":");
		String nomePrincipal = regras[0].trim();
		fileOutputStream = null;
		System.out.println(regras[1]);
		regras = regras[1].split("\\|");
		try {
			fileOutputStream = new FileOutputStream(new File(path, nomePrincipal + ".h"));
			a += "#ifndef " + nomePrincipal.toUpperCase() + "_h" + System.getProperty("line.separator");
			a += "#define " + nomePrincipal.toUpperCase() + "_h" + System.getProperty("line.separator");
			a += "class " + nomePrincipal + ":" + " public Node" + System.getProperty("line.separator");
			a += "{" + System.getProperty("line.separator");
			a += "\t private:" + System.getProperty("line.separator");
			a += "\t public:" + System.getProperty("line.separator");
			a += "\t\t " + nomePrincipal + "(){}" + System.getProperty("line.separator");
			a += "\t\t virtual ~" + nomePrincipal + "(){}" + System.getProperty("line.separator");
			a += "\t\t " + nomePrincipal + "(const " + nomePrincipal + "&" + " " + nomePrincipal.toLowerCase() + "):"
					+ nomePrincipal + "(" /*+ nomePrincipal.toLowerCase()*/+ "){}" + System.getProperty("line.separator");
			a += "}" + System.getProperty("line.separator");
			a += "//Auto Gerated by Gabriel Calazans" + System.getProperty("line.separator");
			a += "#endif";
			fileOutputStream.write(a.getBytes());
		} catch (IOException e) {
		} finally {
			try {
				fileOutputStream.close();
			} catch (IOException | NullPointerException e) {
			}
		}
		for (int i = 0; i < regras.length; i++) {
			a = "";
			par = regras[i].trim().split(" ");
			try {
				fileOutputStream = new FileOutputStream(new File(path, nomePrincipal.trim() + "Rule" + (i+1) + ".h"));
				a += "#ifndef " + nomePrincipal.toUpperCase() + "RULE" +(i+1) + "_h"
						+ System.getProperty("line.separator");
				a += "#define " + nomePrincipal.toUpperCase() + "RULE" + (i+1) + "_h"
						+ System.getProperty("line.separator");
				a += "#include \"" + nomePrincipal + ".h\"";
				a += "class" + nomePrincipal + "Rule" + (i+1) + ":" + " public " + nomePrincipal
						+ System.getProperty("line.separator");
				a += "{" + System.getProperty("line.separator");
				a += "\t private:" + System.getProperty("line.separator");
				for (String string2 : par) {
					a += "\t\t " + string2 + " " + string2.toLowerCase() + "_;" + System.getProperty("line.separator");
				}
				a += "\t public:" + System.getProperty("line.separator");
				a += "\t\t " + nomePrincipal + "(){}" + System.getProperty("line.separator");
				a += "\t\t " + nomePrincipal + "(){}" + System.getProperty("line.separator");
				a += "\t\t virtual ~" + nomePrincipal + "(){}" + System.getProperty("line.separator");
				a += "\t\t " + nomePrincipal + "(const " + nomePrincipal + "&" + " " + nomePrincipal.toLowerCase() + "):"
						+ nomePrincipal + "(" /*+ nomePrincipal.toLowerCase()*/ + "){}"
						+ System.getProperty("line.separator");
				a += "}" + System.getProperty("line.separator");
				a += "//Auto Gerated by Gabriel Calazans" + System.getProperty("line.separator");
				a += "#endif";
				fileOutputStream.write(a.getBytes());
			} catch (IOException e) {
				System.out.println(e.getMessage());
			} finally {
				try {
					fileOutputStream.close();
				} catch (IOException | NullPointerException e) {
				}
			}
			a += "\t\t " + nomePrincipal + " " + nomePrincipal.toLowerCase() + "_;";
		}
	}

}
