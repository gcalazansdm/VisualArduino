import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class GeraClasse {

	private static final File path = new File("C:\\Users\\Gabriel\\Downloads\\Nova pasta (3)");
	private static LinkedList<Tokens> tokens = new LinkedList<Tokens>();

	public static void main(String[] args) {
		File aux = new File("sintatico.y");
		String line = "";
		String[] elem;
		Scanner s;
		try {
			s = new Scanner(aux);
			while (s.hasNext()) {
				line += s.nextLine().trim();
				System.out.println(line);
				if (line.startsWith("%token")) {
					tokens.add(new Tokens(line.substring(6 + line.indexOf("%token")).trim()));
					line = "";
				}
				if (line.contains(";")) {
					elem = line.split(";");
					geraClasse(elem[0]);
					if (elem.length > 2)
					if (elem.length >= 2) {
						System.out.println(elem[1]);
						line = elem[1].trim();
					} else {
						System.out.println(elem[1]);
						line = "";
					}
				}
			}
		//	System.out.println((new Tokenss("a)m1,1")).equals("a)m1"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void geraClasse(String string) {
		String[] regras;
		String[] par;
		boolean aux = false;
		FileOutputStream fileOutputStream;
		String a = "";
		regras = string.split(":");
		String nomePrincipal = regras[0].trim();
		fileOutputStream = null;
		// System.out.println(regras[1]);
	//	System.out.println(Arrays.toString(regras));
		if(regras[1].indexOf("|")!= 0){
			regras = regras[1].split("\\|");
		}else{
			regras = new String[]{regras[1]};
		}
		try {
			fileOutputStream = new FileOutputStream(new File(path, nomePrincipal + ".h"));
			a += "#ifndef " + nomePrincipal.toUpperCase() + "_H" + System.getProperty("line.separator");
			a += "#define " + nomePrincipal.toUpperCase() + "_H" + System.getProperty("line.separator");
			a += System.getProperty("line.separator");
			a += "#include \"Node.h\"" + System.getProperty("line.separator");
			a += System.getProperty("line.separator");
			a += "class " + nomePrincipal + " :" + " public Node" + System.getProperty("line.separator");
			a += "{" + System.getProperty("line.separator");
			a += "\tprivate:" + System.getProperty("line.separator");
			a += "\tpublic:" + System.getProperty("line.separator");
			a += "\t\t" + nomePrincipal + "():Node(){}" + System.getProperty("line.separator");
			a += "\t\tvirtual ~" + nomePrincipal + "(){}" + System.getProperty("line.separator");
			a += "\t\t" + nomePrincipal + "(const " + nomePrincipal + "&" + " " + nomePrincipal.toLowerCase() + "):"
					+ nomePrincipal + "(" /* + nomePrincipal.toLowerCase() */ + "){}"
					+ System.getProperty("line.separator");
			a += "}" + System.getProperty("line.separator");
		//	a += "//Auto Gerated by Gabriel Calazans" + System.getProperty("line.separator");
			a += "#endif";
			fileOutputStream.write(a.getBytes());
		} catch (IOException e) {
		} finally {
			try {
				fileOutputStream.close();
			} catch (IOException | NullPointerException e) {
			}
		}
		for (int i = 0; i < regras.length; i++) {
			a = "";
			par = regras[i].trim().split(" ");
			try {
				fileOutputStream = new FileOutputStream(new File(path, nomePrincipal.trim() + "Rule" + (i + 1) + ".h"));
				a += "#ifndef " + nomePrincipal.toUpperCase() + "RULE" + (i + 1) + "_H"
						+ System.getProperty("line.separator");
				a += "#define " + nomePrincipal.toUpperCase() + "RULE" + (i + 1) + "_H"
						+ System.getProperty("line.separator");
				a += System.getProperty("line.separator");
				a += "#include \"" + nomePrincipal + ".h\"" + System.getProperty("line.separator");
				for (String string2 : par) {
					if (!tokens.contains(new Tokens(string2)))
						a += "#include \"" + string2 + ".h\"" + System.getProperty("line.separator");
					else if(!aux && tokens.get(tokens.indexOf(new Tokens(string2))).getInclude() != null){
						aux = true;
						a += "#include <string>" + System.getProperty("line.separator");
					}
				}
				a += System.getProperty("line.separator");
				a += "class " + nomePrincipal + "Rule" + (i + 1) + " :" + " public " + nomePrincipal
						+ System.getProperty("line.separator");
				a += "{" + System.getProperty("line.separator");
				a += "\tprivate:" + System.getProperty("line.separator");
				for (String string2 : par) {
					Tokens token;
					if (!tokens.contains(new Tokens(string2)))
						a += "\t\t" + string2 + "* " + string2.toLowerCase() + "_;"
								+ System.getProperty("line.separator");
					else{
						token = tokens.get(tokens.indexOf(new Tokens(string2)));
						a += "\t\t" + (token.getValor()!=null?"Const ":"") + (token.getTipo()!=null?token.getTipo():string2) + " " + string2.toLowerCase() + "_" + (token.getValor()!=null?"= "+token.getValor()+";":";")
								+ System.getProperty("line.separator");
				
					}
				}
				a += "\tpublic:" + System.getProperty("line.separator");
				a += "\t\t" + nomePrincipal + "Rule" + (i + 1) + "(){}" + System.getProperty("line.separator");
				a += "\t\t" + nomePrincipal + "Rule" + (i + 1) + "( ";
				for (String string2 : par) {
					Tokens token;
					if (!tokens.contains(new Tokens(string2))) {
						aux = true;
						a += string2 + "* " + string2.toLowerCase() + ",";
					}else{
						token = tokens.get(tokens.indexOf(new Tokens(string2)));
						if(token.getValor() == null){
							a += string2.toLowerCase() + " " + string2.toLowerCase() + ",";
						}
					}
				}
				if (aux) {
					aux = false;
					a = a.substring(0, a.length() - 1);
				}
				a += "):";
				a += nomePrincipal + "(),";
				for (String string2 : par) {
					Tokens token;
					if (!tokens.contains(new Tokens(string2))) {
						aux = true;
						a += string2.toLowerCase() + "_(" + string2.toLowerCase() + "),";
					}else{
						token = tokens.get(tokens.indexOf(new Tokens(string2)));
						if(token.getValor() == null){
							a += string2.toLowerCase() + "_(" + string2.toLowerCase() + "),";
						}
					}
				}
				a = a.substring(0, a.length() - 1);
				a += "{}" + System.getProperty("line.separator");
				a += "\t\tvirtual ~" + nomePrincipal + "Rule" + (i + 1) + "()" + System.getProperty("line.separator");
				a += "\t\t{" + System.getProperty("line.separator");
				for (String string2 : par) {
					if (!tokens.contains(new Tokens(string2))) {
						a += "\t\t\tdelete" + " " + string2.toLowerCase()+";"+ System.getProperty("line.separator");
					}
				}
				a += "\t\t}" + System.getProperty("line.separator");
				a += "\t\t" + nomePrincipal + "Rule" + (i + 1) + "(const " + nomePrincipal + "Rule" + (i + 1) + "&" + " " + nomePrincipal.toLowerCase() + "):"
						+ nomePrincipal + "(" + nomePrincipal.toLowerCase() + "),";
				for (String string2 : par) {
					Tokens token;
					if (!tokens.contains(new Tokens(string2))) {
						a += string2.toLowerCase() + "_(" + nomePrincipal.toLowerCase() + "->" + string2.toLowerCase()
								+ "_" + "),";
					}
				}
				a = a.substring(0, a.length() - 1);
				a += "{}" + System.getProperty("line.separator");
				for (String string2 : par) {
					Tokens token;
					if (!tokens.contains(new Tokens(string2))) {
						a += "\t\tvoid set_" + string2.toLowerCase() + "(" + string2 + "* " + string2.toLowerCase()
								+ ")" + System.getProperty("line.separator") + "\t\t{"
								+ System.getProperty("line.separator") + "\t\t\t" + string2.toLowerCase() + "_ = "
								+ string2.toLowerCase() + ";" + System.getProperty("line.separator") + "\t\t}"
								+ System.getProperty("line.separator");
						a += "\t\tconst " + string2 + " " + string2.toLowerCase() + " const ()"
								+ System.getProperty("line.separator") + "\t\t{" + System.getProperty("line.separator")
								+ "\t\t\treturn " + string2.toLowerCase() + "_;" + System.getProperty("line.separator")
								+ "\t\t}" + System.getProperty("line.separator");
					}else{
						token = tokens.get(tokens.indexOf(new Tokens(string2)));
						if(token.getValor() == null){
							a += "\t\tvoid set_" + string2.toLowerCase() + "(" + (token.getTipo()!=null?token.getTipo():string2) + "* " + string2.toLowerCase()
							+ ")" + System.getProperty("line.separator") + "\t\t{"
							+ System.getProperty("line.separator") + "\t\t\t" + string2.toLowerCase() + "_ = "
							+ string2.toLowerCase() + ";" + System.getProperty("line.separator") + "\t\t}"
							+ System.getProperty("line.separator");
						}
						a += "\t\t" + (token.getTipo()!=null?token.getTipo():string2) + " " + string2.toLowerCase() + " const ()"
								+ System.getProperty("line.separator") + "\t\t{" + System.getProperty("line.separator")
								+ "\t\t\treturn " + string2.toLowerCase() + "_;" + System.getProperty("line.separator")
								+ "\t\t}" + System.getProperty("line.separator");
					}
				}
				a += "}" + System.getProperty("line.separator");
			//	a += "//Auto Gerated by Gabriel Calazans" + System.getProperty("line.separator");
				a += "#endif";
				fileOutputStream.write(a.getBytes());
			} catch (IOException e) {
				// System.out.println(e.getMessage());
			} finally {
				try {
					fileOutputStream.close();
				} catch (IOException | NullPointerException e) {
				}
			}
			a += "\t\t" + nomePrincipal + " " + nomePrincipal.toLowerCase() + "_;";
		}
	}

}
