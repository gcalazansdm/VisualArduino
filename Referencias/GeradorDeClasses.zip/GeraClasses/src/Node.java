
public class Node {

	private String nome;
	private String[] atributos;

	public String getNome() {
		return nome;
	}

	public String[] getAtributos() {
		return atributos;
	}

	public void setAtributos(String[]  atributos) {
		this.atributos = atributos;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
