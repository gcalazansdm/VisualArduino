
public class Tokens {
	private String token;
	private String valor;
	private String tipo;
	private String include;

	public Tokens(String token) {
		String[] aux = token.split(",");
		if (aux.length > 0)
			if (!aux[0].isEmpty())
				this.token = aux[0];
		if (aux.length > 1) {
			if (!aux[1].isEmpty())
				valor = aux[1];
		}
		//System.out.println(valor);
		if (aux.length > 2)
			if (!aux[2].isEmpty())
				tipo = aux[2];
		if (aux.length > 3)
			if (!aux[3].isEmpty())
				include = aux[3];
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Tokens) {
			return token.equals(((Tokens) obj).getToken());
		}
		if (obj instanceof String) {
			System.out.println(token.equals(((String) obj)));
			return token.equals(((String) obj));
		}
		System.out.println(token.equals(((String) obj)));
		return super.equals(obj);
	}

	public String getToken() {
		return token;
	}

	public String getValor() {
		return valor;
	}

	public String getTipo() {
		return tipo;
	}

	public String getInclude() {
		return include;
	}

	@Override
	public String toString() {
		return token;
	}
}
